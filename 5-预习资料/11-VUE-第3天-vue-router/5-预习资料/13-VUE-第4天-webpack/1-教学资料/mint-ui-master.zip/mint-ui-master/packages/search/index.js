export { default } from './src/search.vue';
